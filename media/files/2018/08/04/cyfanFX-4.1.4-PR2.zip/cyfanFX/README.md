# cyfanFX V4.1.x ver. #

### 更改日志 ###

- 更换为CC4.0许可证  
- 改进 HiFX-电影 与 HiFX-音乐  
- 重新加入HiFX-Live(待改进)  

### 版权许可 ###

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">CC BY-NC-SA 4.0</a>进行许可。

作者博客：http://cyfan.cf

脉冲样本下载自V4A论坛与酷安V4A评论区，版权归原作者所有。

### 个性化配置 ###

1. 清晰度设置。耳机->ViPER清晰度->选择清晰度，推荐值6，8，10。

2. 混响度设置。耳机->数字混响->混响信号比例，推荐值0，6，17，22。

3. 输出音量调整。耳机->总输出门(限幅)->输出增益，或耳机->数字混响->原始信号比例。
