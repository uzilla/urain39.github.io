Feel free to fork.
Please keep the link in the bottom.

The like button is currently for personal use and would not work on any other domain.
Please delete all the lines between `<!-- BEGIN this would not work on any other domain -->` and `<!-- END this would not work on any other domain -->`
